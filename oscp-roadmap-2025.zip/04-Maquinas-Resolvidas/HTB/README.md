# Máquinas Hack The Box Resolvidas

Aqui estão as máquinas que resolvi no HTB, com anotações e passos detalhados.

Formato padrão para cada máquina:

- Nome da máquina
- Data de resolução
- Resumo da exploração
- Enumeração
- Privesc
- Pós-exploração
- Scripts usados
- Dicas e links úteis
