# Checklist para Relatório OSCP

- Descrição do alvo e escopo
- Enumeração detalhada
- Explorações testadas
- Resultado das explorações
- Captura da flag (user e root)
- Comandos usados
- Referências
- Apresentação clara e objetiva
