# Buffer Overflow - Conceitos Básicos

- Entender stack e heap
- Identificar overflow em input
- Uso de ferramentas: Immunity Debugger, Mona.py
- Fuzzing para encontrar offset
- Construir payloads básicos em Python
