# Plano Final para o Exame OSCP

- Durma bem nos dias anteriores
- Organize todo o ambiente de trabalho
- Tenha scripts prontos para enumeração e pós-exploração
- Faça pausas durante a prova para manter a concentração
- Documente tudo detalhadamente para o relatório
- Revisite as máquinas e exploits já resolvidos
