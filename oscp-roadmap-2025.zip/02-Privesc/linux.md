# Escalada de Privilégios em Linux

- Verificar SUID/SGID
- Serviços com privilégios
- Cron jobs inseguros
- Permissões de arquivos
- Kernel exploits (se aplicável)
