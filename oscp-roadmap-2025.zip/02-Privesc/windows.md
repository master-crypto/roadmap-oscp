# Escalada de Privilégios em Windows

- SeImpersonatePrivilege
- UAC Bypass
- Serviços configurados incorretamente
- Técnicas com PowerShell
- Ferramentas: WinPEAS, SharpUp
