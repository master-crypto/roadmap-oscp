# Cheatsheets para Privesc

## Linux
- find / -perm -4000 2>/dev/null
- ps aux --sort=-%mem | head
- sudo -l

## Windows
- whoami /priv
- net user
- Get-Process
