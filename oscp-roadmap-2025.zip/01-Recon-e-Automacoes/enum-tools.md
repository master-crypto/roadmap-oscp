# Ferramentas de Enumeração

- **Nmap:** Scanner de portas e serviços
- **Gobuster:** Enumeração de diretórios e arquivos web
- **Nikto:** Scanner de vulnerabilidades web
- **Enum4linux:** Enumeração em ambientes Windows
