# Lista de Ferramentas para Reconhecimento

- nmap
- gobuster
- nikto
- enum4linux
- dirb
- curl
- wget
